﻿namespace SalesTax.Enums
{
	public enum CartItemType
	{
		Misc = 1,
		Book = 2,
		Food = 4,
		Medical = 8
	}
}
